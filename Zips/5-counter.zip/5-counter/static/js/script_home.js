function clear(name){
    document.getElementById(name).innerHTML = "0";
}